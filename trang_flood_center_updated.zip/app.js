const stations = [
  {id:1,name:"สถานีแม่น้ำตรัง",district:"เมืองตรัง",sub:"ทับเที่ยง",level:1.42,status:"watch",trend:"+0.08",time:"14:30",lat:7.5564,lng:99.6114},
  {id:2,name:"คลองนางน้อย",district:"เมืองตรัง",sub:"นาโต๊ะหมิง",level:0.92,status:"normal",trend:"-0.03",time:"14:25",lat:7.595,lng:99.62},
  {id:3,name:"คลองชี",district:"กันตัง",sub:"กันตัง",level:1.78,status:"risk",trend:"+0.14",time:"14:28",lat:7.411,lng:99.514},
  {id:4,name:"แม่น้ำตรังตอนบน",district:"ห้วยยอด",sub:"ห้วยยอด",level:0.86,status:"normal",trend:"-0.02",time:"14:20",lat:7.79,lng:99.635},
  {id:5,name:"คลองลำภูรา",district:"ห้วยยอด",sub:"ลำภูรา",level:1.16,status:"watch",trend:"+0.05",time:"14:24",lat:7.705,lng:99.59},
  {id:6,name:"คลองวังวิเศษ",district:"วังวิเศษ",sub:"วังมะปราง",level:1.63,status:"risk",trend:"+0.11",time:"14:22",lat:7.72,lng:99.37},
  {id:7,name:"คลองย่านตาขาว",district:"ย่านตาขาว",sub:"ย่านตาขาว",level:1.24,status:"watch",trend:"+0.04",time:"14:27",lat:7.39,lng:99.67},
  {id:8,name:"คลองปะเหลียน",district:"ปะเหลียน",sub:"ท่าข้าม",level:2.08,status:"danger",trend:"+0.19",time:"14:31",lat:7.18,lng:99.86},
  {id:9,name:"คลองนาโยง",district:"นาโยง",sub:"นาโยง",level:1.31,status:"watch",trend:"+0.02",time:"14:21",lat:7.55,lng:99.69},
  {id:10,name:"คลองสิเกา",district:"สิเกา",sub:"บ่อหิน",level:0.74,status:"normal",trend:"-0.01",time:"14:18",lat:7.56,lng:99.33}
];

const subdistricts = {
  "เมืองตรัง":["ทับเที่ยง","นาพละ","บ้านควน","นาบินหลา","ควนปริง","นาโยงใต้","บางรัก","โคกหล่อ","นาโต๊ะหมิง","หนองตรุด","น้ำผุด","นาตาล่วง","บ้านโพธิ์","นาท่ามเหนือ","นาท่ามใต้"],
  "กันตัง":["กันตัง","ควนธานี","บางหมาก","บางเป้า","วังวน","กันตังใต้","โคกยาง","คลองลุ","ย่านซื่อ","บ่อน้ำร้อน","บางสัก","นาเกลือ","เกาะลิบง","คลองชีล้อม"],
  "ปะเหลียน":["ท่าข้าม","ทุ่งยาว","ปะเหลียน","บางด้วน","บ้านนา","สุโสะ","ลิพัง","เกาะสุกร","ท่าพญา","แหลมสอม"],
  "ย่านตาขาว":["ย่านตาขาว","หนองบ่อ","นาชุมเห็ด","ในควน","โพรงจระเข้","เกาะเปียะ","ทุ่งกระบือ","ทุ่งค่าย"],
  "สิเกา":["บ่อหิน","เขาไม้แก้ว","กะลาเส","ไม้ฝาด","นาเมืองเพชร"],
  "ห้วยยอด":["ห้วยยอด","หนองช้างแล่น","บางดี","บางกุ้ง","เขากอบ","เขาขาว","เขาปูน","ปากแจ่ม","ปากคม","ท่างิ้ว","ลำภูรา","นาวง","ห้วยนาง","ทุ่งต่อ","ในเตา","วังคีรี"],
  "วังวิเศษ":["เขาวิเศษ","วังมะปราง","อ่าวตง","ท่าสะบ้า","วังมะปรางเหนือ"],
  "นาโยง":["นาโยงเหนือ","ช่อง","ละมอ","โคกสะบ้า","นาหมื่นศรี","นาข้าวเสีย"],
  "รัษฎา":["ควนเมา","คลองปาง","หนองบัว","หนองปรือ","เขาไพร"],
  "หาดสำราญ":["หาดสำราญ","บ้าหวี","ตะเสะ"]
};

const statusText = {normal:"🟢 ปกติ",watch:"🟡 เฝ้าระวัง",risk:"🟠 เสี่ยงน้ำท่วม",danger:"🔴 น้ำท่วม"};
const statusClass = {normal:"normal",watch:"watch",risk:"risk",danger:"danger"};

let selected = stations[0];
let map, markers = [];

function el(id){return document.getElementById(id)}

function renderStations(){
  const grid = el("stationGrid");
  grid.innerHTML = stations.map(s => `
    <article class="station" data-id="${s.id}">
      <div class="station-top">
        <div>
          <div class="station-name">${s.name}</div>
          <div class="station-district">${s.district} · ต.${s.sub}</div>
        </div>
        <span class="status-pill ${statusClass[s.status]}">${statusText[s.status]}</span>
      </div>
      <div class="station-level">${s.level.toFixed(2)} <small>เมตร</small></div>
      <div class="station-bottom"><span>${s.trend.startsWith("-")?"↘":"↗"} ${s.trend} ม.</span><span>อัปเดต ${s.time} น.</span></div>
    </article>
  `).join("");

  document.querySelectorAll(".station").forEach(card=>{
    card.addEventListener("click",()=>{
      const s=stations.find(x=>x.id===Number(card.dataset.id));
      selectStation(s);
    });
  });
}

function selectStation(s){
  selected=s;
  el("selectedArea").textContent=`อำเภอ${s.district} · ต.${s.sub}`;
  el("waterLevel").textContent=s.level.toFixed(2);
  el("trend").textContent=(s.trend.startsWith("-")?"↘ ลดลง ":"↗ เพิ่มขึ้น ")+Math.abs(Number(s.trend)).toFixed(2)+" ม.";
  el("updatedAt").textContent=s.time+" น.";
  el("stationName").textContent="สถานี: "+s.name;
  const pill=el("statusPill");
  pill.className="status-pill "+statusClass[s.status];
  pill.textContent=statusText[s.status];
  const percent=Math.min(94,Math.max(10,(s.level/2.5)*100));
  el("meterFill").style.width=(100-percent)+"%";
  if(map){
    map.setView([s.lat,s.lng],12);
    const m=markers.find(x=>x.station.id===s.id);
    if(m) m.marker.openPopup();
  }
}

function populateSelects(){
  const ds=el("districtSelect");
  ds.innerHTML=Object.keys(subdistricts).map(d=>`<option>${d}</option>`).join("");
  updateSubs();
  ds.addEventListener("change",updateSubs);
}
function updateSubs(){
  const d=el("districtSelect").value;
  el("subdistrictSelect").innerHTML=subdistricts[d].map(x=>`<option>${x}</option>`).join("");
}
function applyArea(){
  const d=el("districtSelect").value, sub=el("subdistrictSelect").value;
  const found=stations.find(s=>s.district===d && s.sub===sub) || stations.find(s=>s.district===d);
  if(found) selectStation(found);
  else {
    el("selectedArea").textContent=`อำเภอ${d} · ต.${sub}`;
    el("waterLevel").textContent="—";
    el("trend").textContent="ยังไม่มีสถานีตัวอย่างในพื้นที่นี้";
  }
  el("locationHint").textContent=`เลือกพื้นที่แล้ว: อำเภอ${d} ตำบล${sub}`;
}

function initMap(){
  map=L.map("map").setView([7.55,99.62],10);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:18,attribution:"© OpenStreetMap contributors"}).addTo(map);
  const colors={normal:"#4caf67",watch:"#e3bd3d",risk:"#e28738",danger:"#d74f4f"};
  markers=stations.map(s=>{
    const marker=L.circleMarker([s.lat,s.lng],{radius:9,fillColor:colors[s.status],color:"#fff",weight:2,fillOpacity:1}).addTo(map);
    marker.bindPopup(`<b>${s.name}</b><br>อ.${s.district} ต.${s.sub}<br><strong>${s.level.toFixed(2)} ม.</strong> · ${statusText[s.status]}<br>อัปเดต ${s.time} น.`);
    return {station:s,marker};
  });
}

function updateCounts(){
  const counts={normal:0,watch:0,risk:0,danger:0};
  stations.forEach(s=>counts[s.status]++);
  el("normalCount").textContent=counts.normal;
  el("watchCount").textContent=counts.watch;
  el("riskCount").textContent=counts.risk;
  el("dangerCount").textContent=counts.danger;
}

function randomRefresh(){
  stations.forEach(s=>{
    const delta=(Math.random()-.45)*.06;
    s.level=Math.max(.2,+(s.level+delta).toFixed(2));
    if(s.level>=1.9)s.status="danger";
    else if(s.level>=1.5)s.status="risk";
    else if(s.level>=1.0)s.status="watch";
    else s.status="normal";
    s.time=new Date().toLocaleTimeString("th-TH",{hour:"2-digit",minute:"2-digit"});
  });
  renderStations(); updateCounts(); selectStation(selected);
  el("locationHint").textContent="อัปเดตข้อมูลตัวอย่างแล้ว · "+new Date().toLocaleTimeString("th-TH",{hour:"2-digit",minute:"2-digit"})+" น.";
}

function locateUser(){
  if(!navigator.geolocation){
    el("locationHint").textContent="เบราว์เซอร์นี้ไม่รองรับการระบุตำแหน่ง";
    return;
  }
  el("locationHint").textContent="กำลังค้นหาตำแหน่งของคุณ…";
  navigator.geolocation.getCurrentPosition(pos=>{
    const {latitude,longitude}=pos.coords;
    let nearest=stations[0], min=Infinity;
    stations.forEach(s=>{
      const d=(s.lat-latitude)**2+(s.lng-longitude)**2;
      if(d<min){min=d;nearest=s;}
    });
    selectStation(nearest);
    el("locationHint").textContent=`พบตำแหน่งของคุณแล้ว · แสดงสถานีที่อยู่ใกล้ที่สุด: ${nearest.name}`;
    if(map) L.marker([latitude,longitude]).addTo(map).bindPopup("ตำแหน่งของคุณ").openPopup();
  },()=>{
    el("locationHint").textContent="ไม่สามารถเข้าถึงตำแหน่งได้ กรุณาอนุญาต Location หรือเลือกอำเภอ/ตำบลด้วยตนเอง";
  });
}

function openModal(type){
  const modal=el("modal"), content=el("modalContent");
  if(type==="report"){
    content.innerHTML=`<h2>📍 แจ้งจุดน้ำท่วม</h2><p>แบบฟอร์มตัวอย่างสำหรับรับแจ้งสถานการณ์จากประชาชน</p>
      <div class="modal-form">
        <input placeholder="ชื่อผู้แจ้ง (ไม่บังคับ)">
        <input placeholder="สถานที่ / ถนน / หมู่บ้าน">
        <select><option>น้ำท่วมขัง</option><option>น้ำไหลเชี่ยว</option><option>ถนนถูกตัดขาด</option><option>อื่น ๆ</option></select>
        <textarea placeholder="รายละเอียดเพิ่มเติม"></textarea>
        <button class="submit-modal" onclick="closeModal();alert('บันทึกแบบฟอร์มตัวอย่างแล้ว — เมื่อต่อระบบจริงให้ส่งข้อมูลเข้า API/ฐานข้อมูล')">ส่งรายงาน</button>
      </div>`;
  }else{
    content.innerHTML=`<h2>🆘 ขอความช่วยเหลือ</h2><p>หากเป็นเหตุฉุกเฉิน ให้ติดต่อหน่วยงานฉุกเฉินในพื้นที่โดยตรง ส่วนฟอร์มนี้เป็นตัวอย่างสำหรับระบบรับเรื่องของเว็บไซต์</p>
      <div class="modal-form">
        <input placeholder="เบอร์โทรศัพท์สำหรับติดต่อกลับ">
        <input placeholder="จุดที่ต้องการความช่วยเหลือ">
        <select><option>อพยพประชาชน</option><option>อาหาร / น้ำดื่ม</option><option>การแพทย์</option><option>เรือ / การเดินทาง</option><option>อื่น ๆ</option></select>
        <textarea placeholder="รายละเอียดและจำนวนผู้ต้องการความช่วยเหลือ"></textarea>
        <button class="submit-modal" onclick="closeModal();alert('ส่งคำขอตัวอย่างแล้ว — เมื่อต่อระบบจริงให้บันทึกลงฐานข้อมูลและแจ้งเจ้าหน้าที่')">ส่งคำขอ</button>
      </div>`;
  }
  modal.classList.add("open");
}
function closeModal(){el("modal").classList.remove("open")}

document.addEventListener("DOMContentLoaded",()=>{
  populateSelects(); renderStations(); updateCounts(); initMap(); selectStation(selected);
  el("districtBtn").addEventListener("click",()=>el("selector").classList.toggle("open"));
  el("applyArea").addEventListener("click",applyArea);
  el("locateBtn").addEventListener("click",locateUser);
  el("locateTop").addEventListener("click",locateUser);
  el("refreshBtn").addEventListener("click",randomRefresh);
  el("reportBtn").addEventListener("click",()=>openModal("report"));
  el("helpBtn").addEventListener("click",()=>openModal("help"));
  el("modalClose").addEventListener("click",closeModal);
  el("modal").addEventListener("click",e=>{if(e.target===el("modal"))closeModal()});
});
